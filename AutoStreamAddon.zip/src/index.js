'use strict';
const { PORT } = require('./constants');
const { startServer } = require('./server');
startServer(PORT);
